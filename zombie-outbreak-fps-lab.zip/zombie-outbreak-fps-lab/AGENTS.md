# Zombie Outbreak FPS Lab

- Projeto experimental independente, autorizado em 06/11/2026. Não editar nem
  enviar commits ao repositório zombie-outbreak-reborn durante este trabalho.
- Base escolhida: beters02/Evostrike, revisão em SOURCE.json. Os fontes inteiros
  estão em upstream/evostrike, preservados byte a byte e sob GPLv2, com avisos
  próprios das dependências. Não copiar mapas de CS ou modelos sem origem.
- O perfil default é de INSPEÇÃO. Fontes ficam inertes em ServerStorage;
  somente os diagnósticos de lab/ executam. Ainda faltam modelos, animações,
  interfaces e efeitos para ativar o motor FPS. Não declarar um jogo funcional.
- Alterações futuras no motor devem acontecer em uma cópia de trabalho separada
  dos originais preservados. Fazer checkpoint antes de mudanças importantes.
- Reutilizar sistemas completos da base, sem voltar a implementar o FPS inteiro
  do zero. Corrigir validação AddWeapon/RemoveWeapon antes de ativar multiplayer.
- Compilar não comprova gameplay, renderização, física ou multiplayer no Studio.
