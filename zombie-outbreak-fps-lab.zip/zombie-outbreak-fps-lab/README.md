# Zombie Outbreak FPS Lab

Experimento independente para adotar o FPS do [Evostrike](https://github.com/beters02/Evostrike),
preservando o projeto `zombie-outbreak-reborn`. **Ainda não é uma partida jogável.**

## O que foi importado

Os **534 arquivos originais**, incluindo 309 arquivos Lua, estão em
`upstream/evostrike`, na revisão `221a3a2f67451145b94836b794c0df072c6a28ee`.
Incluem sistemas de armas, movimento, inventário, compra, skins, facas e modos.
`SOURCE.json` registra a origem e SHA-256 de cada arquivo. Não são somente os
pequenos componentes que foram adaptados no outro projeto.

Os fontes e avisos GPLv2 foram preservados, junto com as licenças próprias das
dependências. [COPYING](COPYING) contém a licença da base; o crédito original
está no [README upstream](upstream/evostrike/README.md). Nenhum mapa, código ou
asset do projeto Zombie Outbreak atual foi alterado ou importado nesta etapa.

## Abrir no Windows

### Publicar o novo repositório

A criação automática no GitHub retornou `Resource not accessible by integration
(createRepository)`. O repositório Git local foi preparado, mas ainda não foi
publicado. O ZIP de entrega inclui a pasta `.git` e o commit inicial.

1. Extraia `zombie-outbreak-fps-lab.zip` em uma pasta diferente do jogo atual.
2. No GitHub Desktop: **File → Add local repository → Choose…** e selecione
   a pasta extraída `zombie-outbreak-fps-lab` (a pasta que contém `.git`).
3. Clique em **Publish repository**, nome `zombie-outbreak-fps-lab`, e mantenha
   **Keep this code private** marcado para começar.
4. Para continuar o desenvolvimento na nuvem, selecione esse novo repositório
   no Codex. A conexão atual está vinculada ao Zombie Outbreak original.

### Abrir o laboratório

1. Clone **este novo repositório** pelo GitHub Desktop, em outra pasta.
   Se acabou de publicar a pasta extraída, ela já está pronta e não exige clone.
2. Salve o place atual e desconecte o Rojo antes de abrir o laboratório.
3. Execute **ABRIR_FPS_LAB.cmd**. Ele confere o checksum e abre
   `builds/Evostrike_Inspection.rbxlx` no Studio. Também pode abrir esse arquivo
   por **File → Open from File**. Não precisa de VS Code ou Codex desktop.
4. Explore **ServerStorage → EvostrikeSource**. Play mostra o diagnóstico de
   pendências; não inicia combate, compra ou movimentação do Evostrike.

O perfil de inspeção armazena os fontes em ServerStorage e não os executa.
Somente os dois diagnósticos de `lab/` ficam ativos. O perfil original está
preservado dentro da pasta upstream; ele depende de objetos ausentes.

## O que falta para ativar o FPS

O checkout recebido tem **zero modelos, MeshParts, Tools, animações ou sons**
no build. Faltam, entre outros:

- Modelos de armas com `GunComponents.WeaponHandle.FirePoint`, modelos locais
  e de terceiros (`ClientModelObject` / `ServerModel`).
- Viewmodel com AnimationController, animações, HUD, imagens e efeitos.
- Adaptação do modo Survival, da autoridade de munição/dano e da economia.
  O acesso `AddWeapon/RemoveWeapon` da base exige validação antes de multiplayer.

A próxima etapa é completar o contrato de assets de **uma arma da própria base**
para validar o fluxo completo câmera → disparo → recarga → troca → servidor.
Só então habilitar o motor e ampliar o arsenal pelo mesmo contrato. Não criar
mais um núcleo FPS próprio nem ativar dois controladores concorrentes.

## Compilar e conferir

Requer Python 3 e Rojo 7.7.1:

```sh
python scripts/build_lab.py
python scripts/check_lab.py
rojo serve default.project.json
```

`check_lab.py --require-ready` falha enquanto faltarem os assets. A compilação,
integridade e isolamento foram verificadas na nuvem. A execução no Studio,
aparência e multiplayer permanecem pendentes.
