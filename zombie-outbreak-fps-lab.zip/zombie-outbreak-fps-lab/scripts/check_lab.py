"""Check source integrity and the isolated inspection place; no engine execution."""
import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]

def check(place):
    manifest=json.loads((ROOT/'SOURCE.json').read_text())
    for name,digest in manifest['files_sha256'].items():
        assert hashlib.sha256((ROOT/'upstream/evostrike'/name).read_bytes()).hexdigest()==digest,name
    assert (ROOT/'COPYING').read_bytes()==(ROOT/'upstream/evostrike/LICENSE.txt').read_bytes()
    root=ET.parse(place).getroot()
    counts=Counter()
    active=[]
    archived=[]
    def walk(parent,path=()):
        for item in parent.findall('Item'):
            name=item.findtext('./Properties/string[@name="Name"]')
            current=(*path,name)
            counts[item.attrib['class']]+=1
            if item.attrib['class'] in ('Script','LocalScript','ModuleScript'):
                target=archived if current[:2]==('ServerStorage','EvostrikeSource') else active
                target.append((current,item))
            walk(item,current)
    walk(root)
    expected={('ServerScriptService','LabReadiness'):'lab/Readiness.server.luau',
              ('StarterPlayer','StarterPlayerScripts','LabStatus'):'lab/Status.client.luau'}
    assert set(path for path,_ in active)==set(expected),'Unexpected executable source outside archive'
    for path,item in active:
        assert item.findtext('./Properties/*[@name="Source"]')==(ROOT/expected[path]).read_text(),path
    assert len(archived)==320, len(archived)
    missing={name:counts[name] for name in ('Model','MeshPart','Tool','Animation','Sound')}
    assert not any(missing.values()),'Assets changed: re-audit before changing readiness status'
    print(f'PASS {len(manifest["files_sha256"])} exact upstream files; {len(archived)} stored scripts/modules; only two lab diagnostics outside ServerStorage')
    print('NOT READY: native weapon/viewmodel/HUD/effect assets absent. Roblox engine not executed.')
    return {'ready':False,'mode':'inspection','upstream_revision':manifest['revision'],
            'preserved_files':len(manifest['files_sha256']),'stored_sources':len(archived),
            'native_assets':missing,'engine_tested':False}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--place',type=Path,default=ROOT/'builds/Evostrike_Inspection.rbxlx')
    parser.add_argument('--require-ready',action='store_true')
    args=parser.parse_args()
    result=check(args.place)
    if args.require_ready and not result['ready']:raise SystemExit(1)
