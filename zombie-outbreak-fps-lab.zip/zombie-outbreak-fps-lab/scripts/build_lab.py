"""Build the inspection profile, verify isolation and write its checksum."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
from check_lab import check

ROOT=Path(__file__).resolve().parents[1]
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rojo',default=shutil.which('rojo'))
    args=parser.parse_args()
    if not args.rojo:parser.error('Provide --rojo PATH or install Rojo 7.7.1')
    output=ROOT/'builds/Evostrike_Inspection.rbxlx'
    subprocess.run([args.rojo,'build','default.project.json','--output',str(output)],cwd=ROOT,check=True)
    result=check(output)
    result.update(file=output.name,sha256=hashlib.sha256(output.read_bytes()).hexdigest(),bytes=output.stat().st_size)
    (ROOT/'builds/FPSLab.release.json').write_text(json.dumps(result,indent=2)+'\n')
