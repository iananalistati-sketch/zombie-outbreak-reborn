$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$manifest = Get-Content -Raw -LiteralPath (Join-Path $projectRoot 'builds\FPSLab.release.json') | ConvertFrom-Json
$place = Join-Path $projectRoot ('builds\' + $manifest.file)
if ((Get-FileHash -Algorithm SHA256 -LiteralPath $place).Hash.ToLowerInvariant() -ne $manifest.sha256) {
    throw 'Checksum diferente. Atualize o repositorio ou recompile o laboratorio.'
}
Write-Host 'Abrindo laboratorio de inspecao; o motor FPS ainda nao esta ativo.'
Start-Process -FilePath $place
